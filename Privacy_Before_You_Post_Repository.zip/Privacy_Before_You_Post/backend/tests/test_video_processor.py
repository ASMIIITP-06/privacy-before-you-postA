import pytest
import cv2
import numpy as np
from app.services.video_processor import process_short_video

def test_invalid_video_is_rejected():
    with pytest.raises(ValueError,match="Invalid or unsupported video"):
        process_short_video(b"this is not a video", "mp4")

def test_short_video_samples_frames(tmp_path):
    path=tmp_path/"short.mp4"
    writer=cv2.VideoWriter(str(path),cv2.VideoWriter_fourcc(*"mp4v"),10,(160,120))
    if not writer.isOpened(): pytest.skip("MP4 encoding is unavailable in this OpenCV build")
    for index in range(10): writer.write(np.full((120,160,3),index*10,dtype=np.uint8))
    writer.release()
    frames,text,metadata=process_short_video(path.read_bytes(),"mp4")
    assert frames and metadata["sampled_frames"]<=6
    assert 0<metadata["duration_seconds"]<=60
