from fastapi.testclient import TestClient
from app.main import app
from app.models.schemas import Finding
from pydantic import ValidationError
import pytest
from io import BytesIO
from PIL import Image

def test_session_lifecycle_and_health():
    with TestClient(app) as client:
        assert client.get("/api/health").json()["status"] == "ok"
        created=client.post("/api/session")
        assert created.status_code == 200
        sid=created.json()["session_id"]
        assert len(sid)>=40
        assert client.delete(f"/api/session/{sid}").status_code == 200
        assert client.delete(f"/api/session/{sid}").status_code == 404

def test_text_analysis_requires_session_and_is_not_fabricated():
    with TestClient(app) as client:
        sid=client.post("/api/session").json()["session_id"]
        response=client.post("/api/analyze",data={"session_id":sid,"caption":"My email is test@example.com"})
        assert response.status_code == 200
        report=response.json()
        assert report["score"]==20 and report["classification"]=="SAFE"
        assert report["ai_status"] in {"not_configured","completed","failed"}
        assert client.post("/api/analyze",data={"session_id":"bad","caption":"anything"}).status_code==401

def test_upload_validation_and_empty_content():
    with TestClient(app) as client:
        sid=client.post("/api/session").json()["session_id"]
        unsupported=client.post("/api/analyze",data={"session_id":sid},files={"file":("payload.exe",b"data","application/octet-stream")})
        assert unsupported.status_code==415
        empty=client.post("/api/analyze",data={"session_id":sid,"caption":"   "})
        assert empty.status_code==422

def test_image_upload_runs_local_processing_without_faking_ai():
    buffer=BytesIO()
    Image.new("RGB",(40,40),(220,220,220)).save(buffer,format="PNG")
    with TestClient(app) as client:
        sid=client.post("/api/session").json()["session_id"]
        response=client.post("/api/analyze",data={"session_id":sid},files={"file":("draft.png",buffer.getvalue(),"image/png")})
        assert response.status_code==200
        report=response.json()
        assert report["ai_status"] in {"not_configured","completed","failed"}
        assert isinstance(report["score"],int)

def test_ai_finding_schema_rejects_invalid_confidence():
    with pytest.raises(ValidationError):
        Finding(category="LOCATION",severity="HIGH",evidence="visible place",confidence=2,explanation="unverified",policy_key="current_location")

def test_provider_configuration_is_explicit(monkeypatch):
    from app.ai import privacy_llm
    monkeypatch.setattr(privacy_llm.settings,"ai_provider","unknown-provider")
    with pytest.raises(privacy_llm.AIUnavailable):
        privacy_llm.get_provider()

def test_expired_session_is_rejected(monkeypatch):
    from app.privacy import session as session_module
    monkeypatch.setattr(session_module.settings,"session_ttl_seconds",0)
    with TestClient(app) as client:
        sid=client.post("/api/session").json()["session_id"]
        response=client.post("/api/analyze",data={"session_id":sid,"caption":"some draft text"})
        assert response.status_code==401
