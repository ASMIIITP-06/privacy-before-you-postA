from app.models.schemas import Finding
from app.risk.scoring import score_findings
from app.analysis.detectors import detect_text

def test_exact_weights_and_boundaries():
    assert score_findings(detect_text("Contact me at person@example.com"))[:2] == (20,"SAFE")
    assert score_findings(detect_text("person@example.com +1 (415) 555-0182"))[:2] == (65,"HIGH RISK")

def test_duplicate_evidence_is_not_double_counted():
    a=Finding(category="PERSONAL",severity="HIGH",evidence="a@b.com",confidence=.98,explanation="email",policy_key="email")
    b=a.model_copy(update={"evidence":"same email repeated"})
    assert score_findings([a,b])[:2] == (20,"SAFE")

def test_multiple_identity_clues_add_policy_weight():
    findings=detect_text("person@example.com, +1 (415) 555-0182")
    score,classification,_,keys=score_findings(findings)
    assert score==65 and classification=="HIGH RISK"
    assert "multiple_identity_clues" in keys

def test_exact_weight_for_every_policy_key():
    expected={"email":20,"phone":25,"address":30,"current_location":25,"routine":20,"id_number":40,"sensitive_document":45,"credential":50,"multiple_identity_clues":20}
    for key,points in expected.items():
        item=Finding(category="CONTEXT",severity="MEDIUM",evidence=key,confidence=1,explanation="evidence",policy_key=key)
        assert score_findings([item])[0]==points

def test_do_not_post_boundary_from_combined_findings():
    items=[Finding(category="SENSITIVE",severity="CRITICAL",evidence=k,confidence=1,explanation="evidence",policy_key=k) for k in ("credential","address","phone")]
    assert score_findings(items)[:2]==(100,"DO NOT POST")

def test_all_fixed_classification_boundaries():
    from app.risk.classifier import classify_score
    assert classify_score(0)[0]=="SAFE"
    assert classify_score(20)[0]=="SAFE"
    assert classify_score(21)[0]=="REVIEW"
    assert classify_score(50)[0]=="REVIEW"
    assert classify_score(51)[0]=="HIGH RISK"
    assert classify_score(75)[0]=="HIGH RISK"
    assert classify_score(76)[0]=="DO NOT POST"
    assert classify_score(100)[0]=="DO NOT POST"

def test_railway_postgres_url_is_normalized_for_asyncpg():
    from app.database.connection import normalize_database_url
    assert normalize_database_url("postgres://user:pass@db:5432/app")=="postgresql+asyncpg://user:pass@db:5432/app"
    assert normalize_database_url("postgresql://user:pass@db:5432/app")=="postgresql+asyncpg://user:pass@db:5432/app"
