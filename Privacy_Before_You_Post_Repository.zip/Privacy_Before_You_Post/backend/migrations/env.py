import asyncio
from alembic import context
from sqlalchemy import pool
from sqlalchemy.ext.asyncio import async_engine_from_config
from app.config import settings
from app.database.connection import Base, normalize_database_url

config=context.config
target_metadata=Base.metadata
config.set_main_option("sqlalchemy.url",(normalize_database_url(settings.database_url) or "postgresql+asyncpg://privacy:privacy@localhost:5432/privacy").replace("%","%%"))

def run_migrations_offline():
    context.configure(url=config.get_main_option("sqlalchemy.url"),target_metadata=target_metadata,literal_binds=True,dialect_opts={"paramstyle":"named"})
    with context.begin_transaction(): context.run_migrations()

def do_run_migrations(connection):
    context.configure(connection=connection,target_metadata=target_metadata)
    with context.begin_transaction(): context.run_migrations()

async def run_migrations_online():
    connectable=async_engine_from_config(config.get_section(config.config_ini_section,{}),prefix="sqlalchemy.",poolclass=pool.NullPool)
    async with connectable.connect() as connection: await connection.run_sync(do_run_migrations)
    await connectable.dispose()

if context.is_offline_mode(): run_migrations_offline()
else: asyncio.run(run_migrations_online())
