from alembic import op
import sqlalchemy as sa

revision="0001_ephemeral_sessions"
down_revision=None
branch_labels=None
depends_on=None

def upgrade():
    op.create_table("ephemeral_sessions",
        sa.Column("id",sa.String(length=64),primary_key=True),
        sa.Column("status",sa.String(length=16),nullable=False,server_default="active"),
        sa.Column("created_at",sa.DateTime(timezone=True),nullable=False),
        sa.Column("expires_at",sa.DateTime(timezone=True),nullable=False),
        sa.Column("analysis_count",sa.Integer(),nullable=False,server_default="0"))
    op.create_index("ix_ephemeral_sessions_expires_at","ephemeral_sessions",["expires_at"])

def downgrade():
    op.drop_index("ix_ephemeral_sessions_expires_at",table_name="ephemeral_sessions")
    op.drop_table("ephemeral_sessions")
