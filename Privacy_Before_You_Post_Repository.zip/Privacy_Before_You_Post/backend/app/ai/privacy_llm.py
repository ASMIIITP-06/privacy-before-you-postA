import base64
import json
from typing import Protocol
from openai import AsyncOpenAI
from app.config import settings
from app.ai.prompts import SYSTEM_PROMPT
from app.models.schemas import Finding

class AIUnavailable(RuntimeError): pass

class PrivacyAIProvider(Protocol):
    async def analyze(self, text: str, image: bytes | list[bytes] | None, mime: str | None): ...

class OpenAIResponsesProvider:
    def __init__(self):
        if not settings.openai_api_key:
            raise AIUnavailable("OPENAI_API_KEY is not configured")
        self.client=AsyncOpenAI(api_key=settings.openai_api_key)

    async def analyze(self, text: str, image: bytes | list[bytes] | None, mime: str | None):
        content = [{"type": "input_text", "text": "Analyze this user draft. Text:\n" + (text or "[No caption or extracted text]")}]
        if image and mime:
            for frame in image if isinstance(image, list) else [image]:
                data = base64.b64encode(frame).decode("ascii")
                content.append({"type": "input_image", "image_url": f"data:{mime};base64,{data}"})
        schema = {"type":"object","additionalProperties":False,"properties":{
            "findings":{"type":"array","items":{"type":"object","additionalProperties":False,"properties":{
                "category":{"type":"string","enum":["PERSONAL","LOCATION","IDENTITY","ROUTINE","SENSITIVE","CONTEXT"]},
                "severity":{"type":"string","enum":["LOW","MEDIUM","HIGH","CRITICAL"]},"evidence":{"type":"string"},"confidence":{"type":"number"},
                "explanation":{"type":"string"},"source":{"type":["string","null"]},"policy_key":{"type":["string","null"]},"recommendation":{"type":"string"}},
                "required":["category","severity","evidence","confidence","explanation","source","policy_key","recommendation"]}},
            "safer_version":{"type":["string","null"]}},"required":["findings","safer_version"]}
        response = await self.client.responses.create(model=settings.openai_model, store=False,
            instructions=SYSTEM_PROMPT, input=[{"role":"user","content":content}],
            text={"format":{"type":"json_schema","name":"privacy_report","strict":True,"schema":schema}})
        payload = json.loads(response.output_text)
        findings = [Finding.model_validate(item) for item in payload["findings"]]
        return findings, payload.get("safer_version")

def get_provider() -> PrivacyAIProvider:
    if settings.ai_provider.lower() == "openai":
        return OpenAIResponsesProvider()
    raise AIUnavailable(f"AI provider '{settings.ai_provider}' is not supported by this build")

async def analyze_with_ai(text: str, image: bytes | list[bytes] | None, mime: str | None):
    return await get_provider().analyze(text,image,mime)
