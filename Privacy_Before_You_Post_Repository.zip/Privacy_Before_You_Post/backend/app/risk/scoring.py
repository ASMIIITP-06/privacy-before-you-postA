from app.models.schemas import Finding
from app.risk.policies import WEIGHTS, CATEGORY_POLICY
from app.risk.classifier import classify_score


def finding_key(finding: Finding) -> str | None:
    if finding.policy_key in WEIGHTS:
        return finding.policy_key
    evidence = f"{finding.category} {finding.evidence}".lower()
    for token, key in CATEGORY_POLICY.items():
        if token in evidence:
            return key
    if finding.category == "ROUTINE": return "routine"
    if finding.category == "IDENTITY": return "multiple_identity_clues"
    if finding.category == "LOCATION": return "current_location"
    return None


def score_findings(findings: list[Finding]) -> tuple[int, str, str, list[str]]:
    # One contribution per policy key prevents duplicate evidence inflation.
    keys = {key for item in findings if (key := finding_key(item))}
    if len(keys & {"email", "phone", "address", "id_number"}) >= 2:
        keys.add("multiple_identity_clues")
    score = min(100, sum(WEIGHTS[key] for key in keys))
    label, meaning = classify_score(score)
    return score, label, meaning, sorted(keys)
