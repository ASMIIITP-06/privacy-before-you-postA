from app.risk.policies import CLASSIFICATIONS

def classify_score(score: int) -> tuple[str, str]:
    if not 0 <= score <= 100:
        raise ValueError("score must be between 0 and 100")
    _, label, meaning = next(item for item in CLASSIFICATIONS if score <= item[0])
    return label, meaning
