WEIGHTS = {
    "email": 20,
    "phone": 25,
    "address": 30,
    "current_location": 25,
    "routine": 20,
    "id_number": 40,
    "sensitive_document": 45,
    "credential": 50,
    "multiple_identity_clues": 20,
}

CLASSIFICATIONS = [
    (20, "SAFE", "No significant exposure detected."),
    (50, "REVIEW", "Potentially identifying information; review before posting."),
    (75, "HIGH RISK", "Significant privacy exposure; changes recommended."),
    (100, "DO NOT POST", "Highly sensitive or significant exposure detected."),
]

CATEGORY_POLICY = {
    "email": "email", "phone": "phone", "address": "address",
    "current location": "current_location", "location": "current_location",
    "routine": "routine", "student id": "id_number", "employee id": "id_number",
    "id card": "id_number", "sensitive document": "sensitive_document",
    "credential": "credential", "password": "credential", "secret": "credential",
    "identity": "multiple_identity_clues",
}
