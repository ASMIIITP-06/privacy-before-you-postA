import tempfile
from pathlib import Path
import cv2
import numpy as np
import pytesseract

def process_short_video(raw: bytes, suffix: str, tesseract_cmd: str | None = None):
    """Sample at most six frames from a <=60 second clip; no video is retained."""
    path = None
    cap = None
    try:
        with tempfile.NamedTemporaryFile(delete=False, suffix="."+suffix) as handle:
            handle.write(raw)
            path = handle.name
        cap = cv2.VideoCapture(path)
        if not cap.isOpened(): raise ValueError("Invalid or unsupported video encoding")
        fps = cap.get(cv2.CAP_PROP_FPS) or 0
        frame_count = cap.get(cv2.CAP_PROP_FRAME_COUNT) or 0
        duration = frame_count / fps if fps > 0 else 0
        if duration <= 0 or duration > 60: raise ValueError("Video must be between 1 and 60 seconds")
        if tesseract_cmd: pytesseract.pytesseract.tesseract_cmd = tesseract_cmd
        count = min(6, max(1, int(duration // 2) + 1))
        frame_bytes, text_parts, ocr_ok = [], [], True
        for i in range(count):
            cap.set(cv2.CAP_PROP_POS_MSEC, (duration * i / max(1, count-1)) * 1000)
            ok, frame = cap.read()
            if not ok: continue
            height, width = frame.shape[:2]
            if width * height > 40_000_000: raise ValueError("Video frame dimensions exceed the supported limit")
            rgb = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)
            scale=min(1.0,1280/max(width,height))
            vision_frame=cv2.resize(frame,(int(width*scale),int(height*scale))) if scale<1 else frame
            ok, encoded = cv2.imencode(".jpg", vision_frame, [int(cv2.IMWRITE_JPEG_QUALITY), 86])
            if ok: frame_bytes.append(encoded.tobytes())
            try: text_parts.append(pytesseract.image_to_string(rgb))
            except Exception: ocr_ok = False
        if not frame_bytes: raise ValueError("No readable frames could be extracted")
        return frame_bytes, "\n".join(part for part in text_parts if part), {"duration_seconds":round(duration,1),"sampled_frames":len(frame_bytes),"ocr_status":"available" if ocr_ok else "unavailable"}
    finally:
        if cap is not None: cap.release()
        if path:
            try: Path(path).unlink(missing_ok=True)
            except OSError: pass
