import re
from app.models.schemas import Finding

PATTERNS = [
    ("email", re.compile(r"\b[A-Z0-9._%+-]+@[A-Z0-9.-]+\.[A-Z]{2,}\b", re.I), "PERSONAL", "HIGH", "email", "An email address can directly identify or contact you.", "Remove or obscure the email address."),
    ("phone", re.compile(r"(?<!\w)(?:\+?\d[\d ().-]{7,}\d)(?!\w)"), "PERSONAL", "HIGH", "phone", "A phone number can be used to contact or link accounts to you.", "Remove or mask the phone number."),
    ("address", re.compile(r"\b\d{1,6}\s+[\w .'-]{2,35}\s(?:street|st|road|rd|avenue|ave|lane|ln|drive|dr|boulevard|blvd)\b", re.I), "LOCATION", "HIGH", "address", "A street address can reveal where you live or spend time.", "Crop or redact the address."),
    ("id_number", re.compile(r"\b(?:student|employee|staff|university|campus)\s*(?:id|no\.?|number)\s*[:#-]?\s*[A-Z0-9-]{4,}\b", re.I), "IDENTITY", "CRITICAL", "id_number", "An institutional identifier can enable impersonation or account lookup.", "Redact the identifier and any barcode or QR code."),
    ("credential", re.compile(r"\b(?:password|passcode|api[_ -]?key|secret)\s*[:=]\s*\S+", re.I), "SENSITIVE", "CRITICAL", "credential", "A visible credential or secret may grant access to an account or system.", "Remove the credential and rotate it if it was exposed."),
]

def detect_text(text: str) -> list[Finding]:
    findings = []
    for name, pattern, category, severity, policy, explanation, recommendation in PATTERNS:
        for match in pattern.finditer(text):
            evidence = match.group(0)[:160]
            findings.append(Finding(category=category, severity=severity, evidence=evidence,
                confidence=0.98, explanation=explanation, source="caption or extracted text",
                policy_key=policy, recommendation=recommendation))
    low = text.lower()
    for terms, evidence, policy, category, explanation, recommendation in [
        (("at home", "my address", "living at"), "Residential location reference", "address", "LOCATION", "The text refers to a residential location.", "Remove specific residence details."),
        (("right now", "here at", "currently at", "at the campus", "at the office"), "Current place reference", "current_location", "LOCATION", "The wording may reveal where you are now.", "Post after leaving and remove precise place details."),
        (("every morning", "every day", "every monday", "daily routine", "usual route"), "Recurring schedule reference", "routine", "ROUTINE", "A repeated schedule can reveal when you are likely to be at a location.", "Remove recurring timing or route details."),
        (("student id", "employee id", "staff id"), "Institutional identifier reference", "id_number", "IDENTITY", "Institutional identifiers can link this post to a specific person or account.", "Remove the identifier."),
    ]:
        if any(term in low for term in terms) and not any(f.policy_key == policy for f in findings):
            findings.append(Finding(category=category, severity="MEDIUM", evidence=evidence, confidence=0.72,
                explanation=explanation, source="caption or extracted text", policy_key=policy, recommendation=recommendation))
    return findings
