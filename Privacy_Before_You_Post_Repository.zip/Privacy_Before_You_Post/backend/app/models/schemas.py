from enum import StrEnum
from pydantic import BaseModel, Field


class Category(StrEnum):
    PERSONAL = "PERSONAL"
    LOCATION = "LOCATION"
    IDENTITY = "IDENTITY"
    ROUTINE = "ROUTINE"
    SENSITIVE = "SENSITIVE"
    CONTEXT = "CONTEXT"


class Severity(StrEnum):
    LOW = "LOW"
    MEDIUM = "MEDIUM"
    HIGH = "HIGH"
    CRITICAL = "CRITICAL"


class Finding(BaseModel):
    category: Category
    severity: Severity
    evidence: str = Field(min_length=1, max_length=500)
    confidence: float = Field(ge=0, le=1)
    explanation: str = Field(min_length=1, max_length=1000)
    source: str | None = None
    policy_key: str | None = None
    recommendation: str = "Review this detail before posting."


class SessionResponse(BaseModel):
    session_id: str
    status: str
    expires_at: str
    ttl_seconds: int


class AnalysisResponse(BaseModel):
    analysis_id: str
    session_id: str
    score: int
    classification: str
    classification_meaning: str
    findings: list[Finding]
    contributing_factors: list[str]
    recommendations: list[str]
    safer_version: str | None
    ai_status: str
    analyzed_at: str
    previous_score: int | None = None
