import secrets
from datetime import datetime, timedelta, timezone
from dataclasses import dataclass, field
from app.config import settings

@dataclass
class EphemeralSession:
    session_id: str
    expires_at: datetime
    analyses: list[dict] = field(default_factory=list)

SESSIONS: dict[str, EphemeralSession] = {}

def create_session() -> EphemeralSession:
    now = datetime.now(timezone.utc)
    item = EphemeralSession(secrets.token_urlsafe(32), now + timedelta(seconds=settings.session_ttl_seconds))
    SESSIONS[item.session_id] = item
    return item

def get_session(session_id: str) -> EphemeralSession | None:
    item = SESSIONS.get(session_id)
    if item and item.expires_at <= datetime.now(timezone.utc):
        SESSIONS.pop(session_id, None)
        return None
    return item

def destroy_session(session_id: str) -> bool:
    return SESSIONS.pop(session_id, None) is not None
