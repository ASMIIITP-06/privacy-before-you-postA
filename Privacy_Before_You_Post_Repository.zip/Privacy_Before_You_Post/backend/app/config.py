from pydantic_settings import BaseSettings, SettingsConfigDict


class Settings(BaseSettings):
    app_env: str = "development"
    api_host: str = "0.0.0.0"
    api_port: int = 8000
    frontend_origins: str = "http://localhost:3000"
    session_ttl_seconds: int = 1800
    max_upload_bytes: int = 15 * 1024 * 1024
    database_url: str | None = None
    redis_url: str | None = None
    openai_api_key: str | None = None
    ai_provider: str = "openai"
    openai_model: str = "gpt-4.1-mini"
    tesseract_cmd: str | None = None
    auto_create_schema: bool = True
    model_config = SettingsConfigDict(env_file=".env", extra="ignore")

    @property
    def origins(self) -> list[str]:
        return [item.strip() for item in self.frontend_origins.split(",") if item.strip()]


settings = Settings()
