import hashlib
import json
from datetime import datetime, timezone
from sqlalchemy import String, DateTime, Integer, text
from sqlalchemy.orm import DeclarativeBase, Mapped, mapped_column
from sqlalchemy.ext.asyncio import create_async_engine, async_sessionmaker
from redis.asyncio import Redis
from app.config import settings

def normalize_database_url(url: str | None) -> str | None:
    if not url: return None
    if url.startswith("postgres://"): return "postgresql+asyncpg://"+url[len("postgres://"):]
    if url.startswith("postgresql://"): return "postgresql+asyncpg://"+url[len("postgresql://"):]
    return url

class Base(DeclarativeBase): pass
class SessionRecord(Base):
    __tablename__ = "ephemeral_sessions"
    id: Mapped[str] = mapped_column(String(64), primary_key=True)
    status: Mapped[str] = mapped_column(String(16), default="active")
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True))
    expires_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), index=True)
    analysis_count: Mapped[int] = mapped_column(Integer, default=0)

database_url=normalize_database_url(settings.database_url)
engine = create_async_engine(database_url, pool_pre_ping=True) if database_url else None
SessionFactory = async_sessionmaker(engine, expire_on_commit=False) if engine else None
redis_client: Redis | None = None

async def initialize():
    global redis_client
    if settings.app_env == "production" and (engine is None or not settings.redis_url):
        raise RuntimeError("Production requires PostgreSQL and Redis configuration")
    if engine and settings.auto_create_schema and settings.app_env == "development":
        async with engine.begin() as conn: await conn.run_sync(Base.metadata.create_all)
    elif engine:
        async with engine.connect() as conn: await conn.execute(text("SELECT 1"))
    if settings.redis_url:
        redis_client=Redis.from_url(settings.redis_url, decode_responses=True)
        await redis_client.ping()

async def close():
    if redis_client: await redis_client.aclose()
    if engine: await engine.dispose()

def _hash(session_id: str) -> str: return hashlib.sha256(session_id.encode()).hexdigest()

async def save_session(session_id: str, created_at: datetime, expires_at: datetime):
    if redis_client:
        ttl=max(1,int((expires_at-datetime.now(timezone.utc)).total_seconds()))
        await redis_client.setex("privacy-session:"+_hash(session_id),ttl,json.dumps({"created_at":created_at.isoformat(),"expires_at":expires_at.isoformat(),"analysis_count":0}))
    if SessionFactory:
        async with SessionFactory() as db:
            key=_hash(session_id); existing=await db.get(SessionRecord,key)
            if existing is None: db.add(SessionRecord(id=key,created_at=created_at,expires_at=expires_at))
            await db.commit()

async def session_is_active(session_id: str) -> bool:
    now=datetime.now(timezone.utc); key=_hash(session_id)
    if redis_client:
        raw=await redis_client.get("privacy-session:"+key)
        if raw:
            try: return datetime.fromisoformat(json.loads(raw)["expires_at"]) > now
            except Exception: return False
    if SessionFactory:
        async with SessionFactory() as db:
            row=await db.get(SessionRecord,key)
            return bool(row and row.status=="active" and row.expires_at>now)
    return False

async def record_analysis(session_id: str):
    key=_hash(session_id)
    if redis_client:
        name="privacy-session:"+key; raw=await redis_client.get(name)
        if raw:
            data=json.loads(raw); ttl=await redis_client.ttl(name); data["analysis_count"]+=1
            await redis_client.setex(name,max(1,ttl),json.dumps(data))
    if SessionFactory:
        async with SessionFactory() as db:
            row=await db.get(SessionRecord,key)
            if row: row.analysis_count+=1; await db.commit()

async def purge_session(session_id: str):
    key=_hash(session_id)
    if redis_client: await redis_client.delete("privacy-session:"+key)
    if SessionFactory:
        async with SessionFactory() as db:
            row=await db.get(SessionRecord,key)
            if row: row.status="destroyed"; await db.commit()
