import io
import time
from contextlib import asynccontextmanager
from datetime import datetime, timezone
from uuid import uuid4
from collections import defaultdict, deque
from fastapi import FastAPI, UploadFile, File, Form, HTTPException, Request
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import JSONResponse
from PIL import Image, ExifTags
from pypdf import PdfReader
import pytesseract
from app.config import settings
from app.models.schemas import SessionResponse, AnalysisResponse
from app.privacy.session import create_session, get_session, destroy_session
from app.analysis.detectors import detect_text
from app.risk.scoring import score_findings
from app.ai.privacy_llm import analyze_with_ai
from app.database.connection import initialize as initialize_data, close as close_data, save_session, session_is_active, record_analysis, purge_session

@asynccontextmanager
async def lifespan(_app: FastAPI):
    await initialize_data()
    try:
        yield
    finally:
        await close_data()

app = FastAPI(title="Privacy Before You Post API", version="0.1.0", description="Ephemeral pre-publication privacy analysis", lifespan=lifespan)
app.add_middleware(CORSMiddleware, allow_origins=settings.origins, allow_credentials=False, allow_methods=["GET","POST","DELETE"], allow_headers=["Content-Type","X-Session-ID"])
_rates: dict[str, deque] = defaultdict(deque)

@app.middleware("http")
async def rate_limit(request: Request, call_next):
    ip = request.client.host if request.client else "unknown"
    now = time.monotonic(); q = _rates[ip]
    while q and now-q[0] > 60: q.popleft()
    if len(_rates)>4096:
        for client, hits in list(_rates.items()):
            while hits and now-hits[0]>60: hits.popleft()
            if not hits: _rates.pop(client,None)
    if len(q) >= 60: return JSONResponse(status_code=429, content={"detail":"Rate limit exceeded. Try again shortly."})
    q.append(now)
    return await call_next(request)

@app.exception_handler(Exception)
async def safe_errors(_request: Request, _exc: Exception):
    return JSONResponse(status_code=500, content={"detail":"Request failed. No content was written to application logs."})

@app.get("/api/health")
async def health():
    return {"status":"ok", "ai_configured":bool(settings.openai_api_key and settings.ai_provider.lower()=="openai"), "database_configured":bool(settings.database_url), "redis_configured":bool(settings.redis_url)}

@app.post("/api/session", response_model=SessionResponse)
async def new_session():
    item = create_session()
    await save_session(item.session_id, datetime.now(timezone.utc), item.expires_at)
    return SessionResponse(session_id=item.session_id, status="active", expires_at=item.expires_at.isoformat(), ttl_seconds=settings.session_ttl_seconds)

@app.delete("/api/session/{session_id}")
async def close_session(session_id: str):
    if not destroy_session(session_id) and not await session_is_active(session_id): raise HTTPException(404, "Session not found or expired")
    await purge_session(session_id)
    return {"status":"destroyed"}

def _extract_file(raw: bytes, filename: str, content_type: str):
    text, image_data, image_mime, metadata = "", None, None, {}
    suffix = filename.lower().rsplit(".",1)[-1] if "." in filename else ""
    if content_type.startswith("image/") and suffix in {"png","jpg","jpeg","webp","bmp","tiff"}:
        try:
            im = Image.open(io.BytesIO(raw)); im.verify(); im = Image.open(io.BytesIO(raw))
            if im.width * im.height > 40_000_000: raise HTTPException(413,"Image dimensions exceed the supported limit")
            exif = im.getexif()
            for tag, value in exif.items():
                name = ExifTags.TAGS.get(tag, str(tag))
                if name == "GPSInfo": metadata["gps_metadata_present"] = True
                if name in {"DateTimeOriginal","Make","Model"}: metadata[name] = str(value)[:80]
            image_data, image_mime = raw, content_type
            metadata["ocr_status"]="available"
            try:
                if settings.tesseract_cmd: pytesseract.pytesseract.tesseract_cmd = settings.tesseract_cmd
                text = pytesseract.image_to_string(im)
            except Exception: metadata["ocr_status"]="unavailable"
            # Strip EXIF and bound the image sent to an external vision provider.
            vision_image=im.convert("RGB")
            vision_image.thumbnail((1600,1600))
            normalized=io.BytesIO(); vision_image.save(normalized,format="JPEG",quality=86,optimize=True)
            image_data,image_mime=normalized.getvalue(),"image/jpeg"
        except HTTPException: raise
        except Exception: raise HTTPException(415,"Invalid or unsupported image file")
    elif content_type in {"video/mp4","video/quicktime","video/webm"} and suffix in {"mp4","mov","webm"}:
        try:
            from app.services.video_processor import process_short_video
            image_data,text,video_meta=process_short_video(raw,suffix,settings.tesseract_cmd)
            image_mime="image/jpeg"; metadata.update(video_meta)
        except ValueError as exc: raise HTTPException(415,str(exc))
        except ImportError: raise HTTPException(503,"Short-video processing is unavailable because OpenCV is not installed")
        except Exception: raise HTTPException(415,"Could not process this video")
    elif suffix == "pdf" and content_type == "application/pdf":
        try:
            reader=PdfReader(io.BytesIO(raw)); text="\n".join((page.extract_text() or "") for page in reader.pages[:30])
            metadata["pdf_text_status"]="available" if text.strip() else "no_embedded_text"
        except Exception: raise HTTPException(415,"Invalid PDF file")
    elif suffix in {"txt","md"} and content_type in {"text/plain","text/markdown","application/octet-stream"}:
        text=raw.decode("utf-8",errors="replace")[:100_000]
    else: raise HTTPException(415,"Supported formats: PNG, JPG, WEBP, BMP, TIFF, PDF, TXT, MD")
    return text, image_data, image_mime, metadata

async def _analyze(session_id: str, caption: str, file: UploadFile | None):
    session = get_session(session_id)
    if not session and not await session_is_active(session_id): raise HTTPException(401,"Session is invalid or expired. Start a new private session.")
    if not caption.strip() and file is None: raise HTTPException(422,"Provide caption text or one supported file.")
    raw=b""; extracted=""; image_data=None; image_mime=None; metadata={}
    if file:
        if file.content_type not in {"image/png","image/jpeg","image/webp","image/bmp","image/tiff","application/pdf","text/plain","text/markdown","application/octet-stream","video/mp4","video/quicktime","video/webm"}:
            raise HTTPException(415,"Unsupported media type")
        raw=await file.read(settings.max_upload_bytes+1)
        if len(raw)>settings.max_upload_bytes: raise HTTPException(413,"File exceeds the 15 MB limit")
        extracted,image_data,image_mime,metadata=_extract_file(raw,file.filename or "upload",file.content_type or "")
    combined="\n".join(x for x in (caption,extracted) if x)
    findings=detect_text(combined)
    if metadata.get("gps_metadata_present"):
        from app.models.schemas import Finding
        findings.append(Finding(category="LOCATION",severity="HIGH",evidence="GPS location metadata present in image",confidence=1,explanation="The image contains embedded GPS coordinates that may reveal where it was captured.",source="image metadata",policy_key="current_location",recommendation="Remove location metadata before sharing."))
    if metadata.get("DateTimeOriginal"):
        from app.models.schemas import Finding
        findings.append(Finding(category="ROUTINE",severity="LOW",evidence="Image capture timestamp is embedded in metadata",confidence=1,explanation="A capture timestamp can reveal when an image was taken, especially when combined with location or routine clues.",source="image metadata",policy_key="routine",recommendation="Remove the capture timestamp if it could expose your schedule."))
    ai_status="not_configured"; safer=None
    if settings.openai_api_key:
        try:
            ai_findings,safer=await analyze_with_ai(combined,image_data,image_mime)
            findings.extend(ai_findings); ai_status="completed"
        except Exception:
            ai_status="failed"
    score,label,meaning,keys=score_findings(findings)
    recommendations=list(dict.fromkeys(f.recommendation for f in findings))
    if metadata.get("ocr_status")=="unavailable": recommendations.append("Local OCR was unavailable, so visible text in the image may not have been evaluated. Install Tesseract OCR.")
    if metadata.get("pdf_text_status")=="no_embedded_text": recommendations.append("No embedded text was found in this PDF. Scanned-page OCR is not enabled, so its page images were not evaluated.")
    if ai_status!="completed": recommendations.append("Configure the AI provider to enable image context analysis and a generated safer rewrite.")
    digest=uuid4().hex[:20]
    result=AnalysisResponse(analysis_id=digest,session_id=session_id,score=score,classification=label,
        classification_meaning=meaning,findings=findings,contributing_factors=keys,recommendations=recommendations,
        safer_version=safer,ai_status=ai_status,analyzed_at=datetime.now(timezone.utc).isoformat(),
        previous_score=session.analyses[-1]["score"] if session and session.analyses else None)
    if session: session.analyses.append({"analysis_id":digest,"score":score})
    await record_analysis(session_id)
    # Discard request content buffers as soon as analysis completes.
    raw=b""; extracted=""; combined=""; image_data=None
    return result

@app.post("/api/analyze", response_model=AnalysisResponse)
async def analyze(session_id: str = Form(...), caption: str = Form(""), file: UploadFile | None = File(None)):
    if len(caption)>20_000: raise HTTPException(413,"Caption exceeds the 20,000 character limit")
    return await _analyze(session_id,caption,file)

@app.post("/api/analyze/recheck", response_model=AnalysisResponse)
async def recheck(session_id: str = Form(...), caption: str = Form(""), file: UploadFile | None = File(None)):
    if len(caption)>20_000: raise HTTPException(413,"Caption exceeds the 20,000 character limit")
    return await _analyze(session_id,caption,file)
