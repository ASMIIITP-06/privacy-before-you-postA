# Privacy Before You Post

An ephemeral pre-publication privacy analyzer. It combines evidence-based text/OCR and image metadata checks, optional AI observations, a deterministic 0–100 scoring policy, a safer rewrite, and user-controlled re-analysis.

## Start locally

Prerequisites: Python 3.12+, Node.js 20.9+, PostgreSQL 16+, and Redis 7+. Tesseract OCR is optional for local Python runs; the backend Docker image includes English Tesseract data.

1. Copy `backend/.env.example` to `backend/.env` and set PostgreSQL/Redis URLs. Set `OPENAI_API_KEY` to enable model-based image/context analysis and safer rewrites. Without credentials, deterministic detections still run and the API explicitly returns `ai_status: not_configured`.
2. Start PostgreSQL and Redis, then run `cd backend; python -m venv .venv; .\.venv\Scripts\python.exe -m pip install -r requirements.txt; .\.venv\Scripts\python.exe -m uvicorn app.main:app --reload --no-access-log` (PowerShell). On macOS/Linux use `.venv/bin/python -m pip` and `.venv/bin/uvicorn`.
3. In a second terminal run `cd frontend; copy .env.example .env.local; npm install; npm run dev`.
4. Open http://localhost:3000. API docs are at http://localhost:8000/docs.

For local-only development without PostgreSQL or Redis, leave their URLs blank. Sessions remain in process memory, so they do not survive backend restarts and are unsuitable for multi-worker deployment.

## Docker Compose

Copy `.env.example` to `.env`, set a strong `POSTGRES_PASSWORD` and (optionally) `OPENAI_API_KEY`, then:

```sh
docker compose up --build
docker compose exec backend alembic upgrade head
```

The app is at http://localhost:3000 and the API at http://localhost:8000. For deployments, use TLS, replace development secrets, restrict CORS to the deployed frontend, configure the AI provider's data-retention terms, and use a managed/secured PostgreSQL and Redis service.

## Railway deployment

The repository has Railway service configs at `backend/railway.toml` and `frontend/railway.toml`. Create one Railway project with PostgreSQL, Redis, and two empty services (`backend` and `frontend`). Railway can deploy local directories with its CLI, so a GitHub repository is optional; its CLI documentation lists Windows/npm installation and local directory uploads.

1. Connect/sign in to Railway, create the project, then provision PostgreSQL and Redis services.
2. Create empty `backend` and `frontend` services. The per-service `railway.toml` files set the backend migration and health check. Install the CLI with `npm install -g @railway/cli`, then sign in with `railway login`.
3. In `backend/`, run `railway link` and select the project, environment, and backend service; then run `railway up`. Set: `APP_ENV=production`, `AUTO_CREATE_SCHEMA=false`, `DATABASE_URL=${{Postgres.DATABASE_URL}}`, `REDIS_URL=${{Redis.REDIS_URL}}`, `AI_PROVIDER=openai`, `OPENAI_MODEL=gpt-4.1-mini`, and `OPENAI_API_KEY`. Enter the API key directly into Railway's sealed variable UI; never commit or paste it into chat.
4. Generate the backend's Railway domain. Set backend `FRONTEND_ORIGINS` to the final frontend HTTPS origin.
5. Set the frontend service's `NEXT_PUBLIC_API_URL` to the backend's HTTPS domain **before building**. The Dockerfile declares this as a build argument, and Next.js embeds it into the client bundle. In `frontend/`, run `railway link` and select the same project/environment and frontend service, then run `railway up`; generate its public domain.
6. Verify `https://<backend-domain>/api/health`, `https://<backend-domain>/docs`, and the frontend flow. Run a text analysis, image upload, PDF upload, re-analysis, and session deletion against the deployed services.

Railway assigns domains only after a service is deployed and a domain is generated; this workspace has no Railway account session or deploy token, so no public URL is available yet. Keep PostgreSQL and Redis private; connect them through Railway reference variables. Railway variables can be sealed, and a generated public domain receives HTTPS automatically. Railway pricing is account-specific; review the plan and usage before deploying paid resources.

## AI and privacy behavior

`backend/app/ai/privacy_llm.py` exposes a provider interface with an OpenAI Responses API adapter. It uses a Pydantic-validated strict JSON schema, image input, and `store=False`. Set `AI_PROVIDER=openai`; the configured model is `gpt-4.1-mini` by default and can be changed with `OPENAI_MODEL`. Model findings are observations only; `backend/app/risk/scoring.py` assigns fixed weights and classifications. The app never publishes content.

The app does not store captions, uploads, OCR output, or reports in PostgreSQL or Redis. PostgreSQL stores only a hash of the session ID, status, expiry, and analysis count. Redis stores the same minimal session metadata with TTL. The latest report is held in browser `sessionStorage` for the active tab and cleared when the session ends or expires (or the tab closes). Starlette may spool larger multipart uploads to a temporary OS file; the request file is closed after response completion. Analysis state is otherwise transient in the API process. On session end, Redis state is removed and the database metadata is marked destroyed. Expired database metadata is retained as minimal metadata; schedule cleanup according to your retention policy. Process memory, temporary-file recovery, reverse-proxy logs, infrastructure backups, and third-party AI processing are outside the app's deletion boundary. The product therefore describes an *ephemeral / zero-persistence session design intent*, not guaranteed permanent deletion.

The AI provider is an external processor whenever enabled. Do not send sensitive content until you have reviewed the provider's current retention and data-processing settings for your account. API keys remain server-side. Without the key, image understanding and AI safer rewrites are unavailable; no simulated results are generated.

## Supported input and limits

PNG, JPEG, WEBP, BMP, TIFF, text, Markdown, PDF, MP4, MOV, and WEBM; 15 MB maximum, 40 megapixels maximum for images, and 60 seconds maximum for video. PDF text extraction covers the first 30 pages; scanned PDF OCR is not enabled. Image and sampled video-frame OCR uses local Tesseract when available. Video processing samples up to six frames, removes its temporary file after processing, and does not analyze audio. Images and sampled video frames can receive AI vision analysis only when configured. MIME and extension checks are applied, but production deployments should add malware scanning and isolated file-processing workers.

## Score policy

| Exposure | Points |
|---|---:|
| Email | 20 |
| Phone | 25 |
| Address | 30 |
| Current location | 25 |
| Routine information | 20 |
| Student/employee ID | 40 |
| Sensitive document | 45 |
| Credential/secret | 50 |
| Multiple identity clues | 20 |

Duplicate policy keys are counted once and the total is capped at 100. Classifications: 0–20 SAFE, 21–50 REVIEW, 51–75 HIGH RISK, 76–100 DO NOT POST.

## Database migrations

Development can create the minimal session table on startup (`AUTO_CREATE_SCHEMA=true`). Production should use migrations:

```sh
cd backend
alembic upgrade head
```

## Tests and build

```sh
cd backend
python -m pytest
cd ../frontend
npm run build
```

## Current boundaries

OCR quality depends on image legibility and Tesseract installation. The built-in deterministic detector is intentionally conservative and is not a guarantee of safety. AI output remains subject to model error; findings are schema-validated but require user judgment. Rate limiting is process-local and should be replaced by shared infrastructure for horizontally scaled deployments. The test suite exercises scoring, deduplication, lifecycle, and API behavior; production security, adversarial evaluation, monitoring, backups, TLS, and deletion across external infrastructure still need deployment-specific verification.
