from io import BytesIO
from pathlib import Path
from httpx import Client
from PIL import Image
from pypdf import PdfReader

def pdf_with_text(text: str) -> bytes:
    escaped=text.replace("\\","\\\\").replace("(","\\(").replace(")","\\)").encode("ascii")
    stream=b"BT /F1 12 Tf 30 100 Td ("+escaped+b") Tj ET"
    objects=[
        b"<< /Type /Catalog /Pages 2 0 R >>",
        b"<< /Type /Pages /Kids [3 0 R] /Count 1 >>",
        b"<< /Type /Page /Parent 2 0 R /MediaBox [0 0 300 144] /Resources << /Font << /F1 4 0 R >> >> /Contents 5 0 R >>",
        b"<< /Type /Font /Subtype /Type1 /BaseFont /Helvetica >>",
        b"<< /Length "+str(len(stream)).encode()+b" >>\nstream\n"+stream+b"\nendstream",
    ]
    out=bytearray(b"%PDF-1.4\n"); offsets=[0]
    for i,obj in enumerate(objects,1):
        offsets.append(len(out)); out.extend(f"{i} 0 obj\n".encode()+obj+b"\nendobj\n")
    xref=len(out); out.extend(f"xref\n0 {len(offsets)}\n0000000000 65535 f \n".encode())
    for offset in offsets[1:]: out.extend(f"{offset:010d} 00000 n \n".encode())
    out.extend(f"trailer\n<< /Size {len(offsets)} /Root 1 0 R >>\nstartxref\n{xref}\n%%EOF".encode())
    return bytes(out)

with Client(timeout=30) as client:
    health=client.get("http://127.0.0.1:8000/api/health")
    assert health.status_code==200,health.text
    sid=client.post("http://127.0.0.1:8000/api/session").json()["session_id"]
    form={"session_id":sid,"caption":"Contact me at person@example.com"}
    first=client.post("http://127.0.0.1:8000/api/analyze",data=form)
    assert first.status_code==200,first.text
    assert (first.json()["score"],first.json()["classification"])==(20,"SAFE"),first.text
    changed=client.post("http://127.0.0.1:8000/api/analyze/recheck",data={"session_id":sid,"caption":"person@example.com +1 (415) 555-0182"})
    assert changed.status_code==200,changed.text
    assert (changed.json()["score"],changed.json()["classification"],changed.json()["previous_score"])==(65,"HIGH RISK",20),changed.text
    image=Image.new("RGB",(48,48),(180,180,180)); exif=Image.Exif(); exif[36867]="2026:11:05 12:00:00"
    img=BytesIO(); image.save(img,format="PNG",exif=exif)
    image_result=client.post("http://127.0.0.1:8000/api/analyze",data={"session_id":sid},files={"file":("timestamp.png",img.getvalue(),"image/png")})
    assert image_result.status_code==200,image_result.text
    assert image_result.json()["score"]==20,image_result.text
    pdf=pdf_with_text("private@example.com")
    assert PdfReader(BytesIO(pdf)).pages[0].extract_text().strip()=="private@example.com"
    pdf_result=client.post("http://127.0.0.1:8000/api/analyze",data={"session_id":sid},files={"file":("draft.pdf",pdf,"application/pdf")})
    assert pdf_result.status_code==200,pdf_result.text
    assert (pdf_result.json()["score"],pdf_result.json()["classification"])==(20,"SAFE"),pdf_result.text
    closed=client.delete(f"http://127.0.0.1:8000/api/session/{sid}")
    assert closed.status_code==200,closed.text
    print({"health":health.json(),"caption_score":first.json()["score"],"recheck_score":changed.json()["score"],"image_score":image_result.json()["score"],"pdf_score":pdf_result.json()["score"],"session_destroyed":closed.json()["status"]})
