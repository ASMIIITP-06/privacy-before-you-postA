import Link from "next/link";
export const dynamic = "force-dynamic";
export default function NotFound(){return <main className="shell flex min-h-screen items-center justify-center px-6"><section className="rounded-2xl border border-line bg-panel p-8 text-center"><h1 className="serif text-2xl font-semibold">Page not found</h1><p className="mt-2 text-xs text-slate-500">That page is not available.</p><Link href="/" className="mt-5 inline-flex rounded-full bg-mint px-5 py-2.5 text-xs font-bold text-ink">Return home</Link></section></main>}
