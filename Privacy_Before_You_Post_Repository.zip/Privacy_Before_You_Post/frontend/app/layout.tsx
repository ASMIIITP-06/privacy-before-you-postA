import type { Metadata } from "next";
import "./globals.css";
export const metadata: Metadata = { title: "Before You Post — Privacy Intelligence", description: "Understand what your draft reveals before you share it." };
export const dynamic = "force-dynamic";
export default function RootLayout({children}:{children:React.ReactNode}){return <html lang="en"><body>{children}</body></html>}
