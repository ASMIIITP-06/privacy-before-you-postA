import type { Config } from "tailwindcss";
const config: Config = { content: ["./app/**/*.{js,ts,jsx,tsx}", "./components/**/*.{js,ts,jsx,tsx}"], theme: { extend: { colors: { ink: "#090e17", panel: "#111a27", line: "#253247", mint: "#8cf0cc", blue: "#92baff" }, boxShadow: { glow: "0 0 50px rgba(105,170,255,.10)" } } }, plugins: [] };
export default config;
