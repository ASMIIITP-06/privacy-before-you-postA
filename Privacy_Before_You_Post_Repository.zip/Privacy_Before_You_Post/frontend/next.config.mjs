/** @type {import('next').NextConfig} */
const nextConfig = { reactStrictMode: true, distDir: ".next-verified", experimental: { cpus: 1, webpackBuildWorker: false } };
export default nextConfig;
